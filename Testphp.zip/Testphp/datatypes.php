<!DOCTYPE html>
<html>
<body>

<?php 
$x = "Hello world!";
$y = 'How are you';

echo $x;
echo "<br>"; 
echo $y;
?> 



</body>
</html>