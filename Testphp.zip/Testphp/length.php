<!DOCTYPE html>
<html>
<body>

<?php
echo strlen("Harisha!");
echo str_word_count("Hello world!");
echo strrev("Hello world!");
echo strpos("Hello world!", "world");
?> 
 
</body>
</html>