<!DOCTYPE html>
<html>
<body>

<?php
$txt1 = "Hello";
$txt2 = "How are you";
$x = 7;
$y = 8;

print "<h2>" . $txt1 . "</h2>";
print " Harisha " . $txt2 . "<br>";
print $x + $y;
?>

</body>
</html>